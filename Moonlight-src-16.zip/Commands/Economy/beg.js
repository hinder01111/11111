const { Discord , MessageActionRow, MessageEmbed , MessageButton} = require("discord.js")
const eco = require("../../database/models/economy")
module.exports = {
  name: "beg",
  description: "Beg for coins",
  run: async(client,message,args) =>{
const amount = Math.floor



let beg = ["YOU BEGGED"]


  }
}