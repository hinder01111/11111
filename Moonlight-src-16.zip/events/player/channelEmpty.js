module.exports = async(queue, client) => {
  
      return client.say.queueMessage(client, queue, "I have left the voice channel as I was left alone. Enable the 24-7 mode if you don't want this to happen!");
    
  };